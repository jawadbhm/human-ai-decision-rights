# Decision Rights in Human–AI Organizations, Version 0.5

**Current release:** 0.5 · November 28, 2026  
**Version DOI:** https://doi.org/10.5281/zenodo.24628610  
**Concept DOI:** https://doi.org/10.5281/zenodo.24584260 (always resolves to the latest version)  
**Previous version:** [0.2](https://doi.org/10.5281/zenodo.24584261)

**Current manuscript:** `Decision_Rights_in_Human_AI_Organizations_v0_5.pdf`  
**LaTeX source:** `Decision_Rights_in_Human_AI_Organizations_v0_5.tex`  
**Public record:** https://doi.org/10.5281/zenodo.24628610

Version 0.5 is the author-approved public release. The PDF uses LaTeX typesetting, fully justified paragraphs, mathematical notation and journal-style tables. Typesetting did not change the scientific content, numerical findings, methods, limitations or provenance. The included DOCX is retained as a pre-typesetting source and is not the current publication layout.

## Research status

The main comparison is a matched synthetic simulation of 1,000 cases per arm. A separate four-arm software pilot evaluates 20 existing fixtures (80 policy evaluations) and its 13 software unit tests passed. The software outputs are diagnostics, not independent empirical evidence or measured human performance. The supplied materials record zero external model calls and zero actual human-review events. No live LLM experiment or human-participant study has been completed; those studies remain prospective.

## Release files and replication

- `Decision_Rights_in_Human_AI_Organizations_v0_5.pdf` — current eight-page working paper.
- `Decision_Rights_in_Human_AI_Organizations_v0_5.tex` — source used for the LaTeX layout.
- `Decision_Rights_v0_5_Publication_Kit.zip` — complete release and replication package, including the PDF, LaTeX source, editable pre-typesetting DOCX, original simulation archive, engineering kit, prospective protocol, analysis code, synthetic fixtures/results, templates and documentation.
- `Human_AI_Decision_Rights_Repository_v0_3.zip` — intentionally preserved historical baseline repository; it is not the current paper or release.

The nested engineering kit's tests concern software behavior only. Run its documented commands in a separate environment. Reproduction commands and limitations are documented in the package and the historical baseline repository.

## Licensing and disclosures

- Version 0.5 manuscript and its LaTeX source: CC BY 4.0.
- Original research software: MIT.
- Original synthetic benchmark and experiment datasets: CC0 1.0.

See `LICENSES.md` for the scope of each license. The package preserves these separate licenses; the record-level manuscript license does not replace the code or data notices. This research received no external funding. The author declares no competing interests. AI assistance supported prototype development, fixture design, computational checks and manuscript preparation; the author is responsible for the research and its interpretation.

## Citation

Bahoum, Jawad (2026). *Decision Rights in Human–AI Organizations: A matched simulation of agent autonomy, human accountability, and review workload* (Version 0.5). Zenodo. https://doi.org/10.5281/zenodo.24628610

The concept DOI, https://doi.org/10.5281/zenodo.24584260, resolves to the latest release. Earlier releases remain available through Zenodo's version history.
