# Approved licenses and scope

- **Working paper v0.5 and LaTeX source:** Creative Commons Attribution 4.0 International (CC BY 4.0), https://creativecommons.org/licenses/by/4.0/. Attribution: Jawad Bahoum (2026), *Decision Rights in Human–AI Organizations*, v0.5.
- **Original source code:** MIT License (see `LICENSE-CODE.txt`).
- **Original synthetic benchmark and experiment datasets** (CSV and case/proposal/benchmark JSON): CC0 1.0 Universal (see `LICENSE-DATA.txt` and https://creativecommons.org/publicdomain/zero/1.0/).

The author approved this Version 0.5 public release and these license scopes on November 28, 2026. These notices apply only to rights held by the author. Third-party cited material, names and trademarks are excluded; underlying facts are not claimed as exclusive property. No license implies endorsement or guarantees fitness for production use. The paper license does not replace the separate MIT code license or CC0 synthetic-data dedication.
