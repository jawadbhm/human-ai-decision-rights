# Version 0.5 — 2026-11-28

Author-approved for public release by Jawad Bahoum on November 28, 2026.

- Version DOI reserved: https://doi.org/10.5281/zenodo.24628610. Zenodo registers the reserved DOI when the version is published.
- Concept DOI preserved: https://doi.org/10.5281/zenodo.24584260.
- Previous published version: 0.2, https://doi.org/10.5281/zenodo.24584261.
- The standalone PDF and archived PDF are byte-for-byte identical.
- Added the final LaTeX source and typeset PDF; bibliography and metadata are synchronized.
- Scientific content, numerical results, methods, limitations and research provenance are unchanged by typesetting.
- No new empirical data were collected. No live-model calls or human-participant studies are claimed; both remain prospective.
- Software, synthetic data and manuscript licenses retain separate scopes as documented in `LICENSES.md`.
