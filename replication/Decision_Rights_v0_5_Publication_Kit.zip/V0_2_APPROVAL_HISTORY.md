# Author approval and disclosure record

> Historical record: This file documents approval-stage facts for manuscript v0.2. Its closing statement that no public deposit or DOI was claimed describes the pre-deposit state when this record was prepared, not the current publication status. Version 0.2 was later published as https://doi.org/10.5281/zenodo.24584261. The author approved Version 0.5 for public release on November 28, 2026; its reserved version DOI is https://doi.org/10.5281/zenodo.24628610, under concept DOI https://doi.org/10.5281/zenodo.24584260.

- Author: Jawad Bahoum.
- Date: November 27, 2026.
- Manuscript version 0.2 approved in chat: “I approve the paper”.
- Funding and competing-interest declarations confirmed in chat: “correct”.
- Publication licenses approved in chat: “I approve all”.
- SHA-256 of original approved PDF (before disclosure corrections): `02c430893f730a402a16bdb584bd2b155fee63bfc71f4943f2ff022b83bccd2e`.

## Confirmed disclosures
Funding: This research received no external funding.

Competing interests: The author declares no competing interests.

The release PDF now incorporates the confirmed approval and disclosures directly on pages 1 and 6. This administrative correction does not alter the research methods, findings or conclusions. Independent validation remains pending.

- SHA-256 of final release PDF: `0bb242c88c44628aeade85777ffcc3c1d87f2d3026cfc68feed34ebbbb28fb0e`. The project was initially framed as a professional work sample for an OpenAI application; OpenAI did not commission or validate it. AI assistance is described in the paper.

## License approvals
Paper: CC BY 4.0. Code: MIT. Synthetic data: CC0 1.0. See LICENSES.md for scope. No public deposit, DOI or GitHub repository is claimed. Final repository/deposit account access and third-party rights checks remain necessary.
