import json,sqlite3,unittest,copy
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import Encoding,PublicFormat
from gateway import *
CASES={c['id']:c for c in json.load(open('pilot_cases.json'))}
class TestGateway(unittest.TestCase):
 def setUp(self):
  self.db=sqlite3.connect(':memory:');init(self.db);self.run='test-only';self.priv={k:Ed25519PrivateKey.generate() for k in ('R1','R2','X1')};self.keys={k:{'role':'execute' if k=='X1' else 'approve','public_key':v.public_key().public_bytes(Encoding.Raw,PublicFormat.Raw).hex()} for k,v in self.priv.items()}
 def tearDown(self):self.db.close()
 def event(self,c,p,arm,k):
  msg=payload(self.run,c,arm,p,self.keys[k]['role'],k);return {'principal':k,'payload':msg,'signature':self.priv[k].sign(canonical(msg)).hex()}
 def act(self,c,p,arm='C',events=()):return execute(self.db,c,p,arm,self.run,events,self.keys)
 def pair(self,id):
  c=CASES[id];return c,{k:c['trusted'][k] for k in ('operation','record_id','value')}
 def test_exact_mandate(self):
  c,p=self.pair('V001');p['record_id']='E200';self.assertEqual(self.act(c,p)['decision'],'BLOCK');self.assertEqual(self.act(c,p,'A')['unsafe'],1)
 def test_typed_value(self):
  c,p=self.pair('V008');p['value']=str(p['value']);self.assertEqual(self.act(c,p)['decision'],'BLOCK')
 def test_protected_no_approvals(self):
  c,p=self.pair('V008');self.assertEqual(self.act(c,p)['decision'],'PENDING')
 def test_dual_and_executor(self):
  c,p=self.pair('V008');es=[self.event(c,p,'C',k) for k in ('R1','R2','X1')];r=self.act(c,p,events=es);self.assertEqual((r['decision'],r['principal'],r['unsafe']),('ALLOW','X1',0));self.assertEqual(self.act(c,p,events=es)['decision'],'REPLAY')
 def test_duplicate_approval(self):
  c,p=self.pair('V008');e=self.event(c,p,'C','R1');self.assertEqual(self.act(c,p,events=[e,e,self.event(c,p,'C','X1')])['decision'],'PENDING')
 def test_no_executor(self):
  c,p=self.pair('V008');self.assertEqual(self.act(c,p,events=[self.event(c,p,'C',k) for k in ('R1','R2')])['decision'],'PENDING')
 def test_wrong_arm(self):
  c,p=self.pair('V008');self.assertEqual(self.act(c,p,events=[self.event(c,p,'B',k) for k in ('R1','R2','X1')])['decision'],'PENDING')
 def test_tampering(self):
  c,p=self.pair('V008');es=[self.event(c,p,'C',k) for k in ('R1','R2','X1')];es[0]['signature']='00'*64;self.assertEqual(self.act(c,p,events=es)['decision'],'PENDING')
 def test_wrong_run(self):
  c,p=self.pair('V008');es=[self.event(c,p,'C',k) for k in ('R1','R2','X1')];self.run='other';self.assertEqual(self.act(c,p,events=es)['decision'],'PENDING')
 def test_rollback(self):
  c,p=self.pair('V032');s=state(self.db);self.assertEqual(self.act(c,p,'D')['decision'],'ROLLBACK');self.assertEqual(s,state(self.db));self.assertEqual(self.db.execute('SELECT count(*) FROM receipts').fetchone()[0],0)
 def test_conflicting_replay(self):
  c,p=self.pair('V001');self.assertEqual(self.act(c,p)['decision'],'ALLOW');p['value']='different';self.assertEqual(self.act(c,p)['decision'],'BLOCK')
 def test_common_stop(self):
  for id in ('V030','V031'):
   c,p=self.pair(id)
   for arm in 'ABCD':self.assertEqual(self.act(c,p,arm)['decision'],'BLOCK')
 def test_blanket_vs_tiered(self):
  c,p=self.pair('V001');self.assertEqual(self.act(c,p,'B')['decision'],'PENDING');self.assertEqual(self.act(c,p,'C')['decision'],'ALLOW')
if __name__=='__main__':unittest.main(verbosity=2)
