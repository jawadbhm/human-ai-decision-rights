"""Offline approval signature utility; one private key per real designated person.
Key generation and signing are explicit operator actions. Do not share private keys.
"""
import argparse,json,os
from pathlib import Path
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import Encoding,PublicFormat,PrivateFormat,NoEncryption
from gateway import canonical,payload,valid
p=argparse.ArgumentParser();sub=p.add_subparsers(dest='command',required=True);g=sub.add_parser('keygen');g.add_argument('--private',type=Path,required=True);g.add_argument('--principal',required=True);g.add_argument('--role',choices=['approve','execute'],required=True);s=sub.add_parser('sign');s.add_argument('--private',type=Path,required=True);s.add_argument('--run',type=Path,required=True);s.add_argument('--task',required=True);s.add_argument('--arm',choices=list('ABCD'),required=True);s.add_argument('--principal',required=True);s.add_argument('--role',choices=['approve','execute'],required=True);a=p.parse_args()
if a.command=='keygen':
 k=Ed25519PrivateKey.generate();fd=os.open(a.private,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'wb') as f:f.write(k.private_bytes(Encoding.Raw,PrivateFormat.Raw,NoEncryption()))
 print(json.dumps({a.principal:{'role':a.role,'public_key':k.public_key().public_bytes(Encoding.Raw,PublicFormat.Raw).hex()}}))
else:
 m=json.loads((a.run/'manifest.json').read_text());c=next(c for c in json.loads((a.run/'cases.json').read_text()) if c['id']==a.task);proposal=json.loads((a.run/'proposals.json').read_text())[a.task]
 if not valid(proposal):raise ValueError('Invalid proposal')
 print(json.dumps({'review_request':c['request'],'proposal':proposal,'arm':a.arm,'role':a.role},indent=2),file=__import__('sys').stderr)
 print('Type APPROVE to sign this exact action: ',file=__import__('sys').stderr,end='',flush=True)
 if input()!='APPROVE':raise SystemExit('Not signed')
 k=Ed25519PrivateKey.from_private_bytes(a.private.read_bytes());msg=payload(m['run'],c,a.arm,proposal,a.role,a.principal);print(json.dumps({'principal':a.principal,'payload':msg,'signature':k.sign(canonical(msg)).hex()}))
