# Decision Rights: live-model pilot engineering package
Status: software pilot executed; no live model calls or actual human review performed. Not a publication release.

## Run
Python 3.10+; install `pip install -r requirements.txt`. Run `python test_gateway.py` and `python paired_analysis.py --self-test`. The included 20 tasks are selected from the project's earlier regression fixtures, not an independent holdout. The included software output uses their original proposals, not LLM predictions. To reproduce, choose fresh directories:

```
python run.py collect --out smoke_new
python run.py evaluate --run smoke_new --out smoke_eval_new
```

For a live model pilot, set `MODEL_API_KEY` securely in your environment (or `OPENAI_API_KEY`), `MODEL_ID` to the provider's supported model ID, and optionally `MODEL_BASE_URL` to its HTTPS OpenAI-compatible API base. Never put keys into source, logs, or a public repository. Each run uses at most 40 calls for 20 tasks; actual charges depend on provider and model. The interface has not been tested with a real provider; some providers/models may require adapter changes. No retries are implemented in this pilot; failures remain noncompletion. Repeat with unique output directories for each model.

```
python run.py collect --live --out live_model_1 --max-calls 40
python run.py evaluate --run live_model_1 --out live_model_1_eval
```

`collect` records the actual request, raw response, provider usage if returned, timing, errors, frozen cases and proposal hashes. It sends only the request and reviewer proposal, never the trusted policy or gold labels. It does not grant model tool access. `evaluate` replays final proposals against four fresh local SQLite states per task. An approval-required action without signed events remains pending, not a randomly simulated review decision. Pending is noncompletion at this snapshot, not a measured human error. The evaluator's safety/completion labels are derived from trusted fixtures and must not substitute for independent outcome adjudication. Software outputs are supplied for debugging only.

## Approval and protected actions
Designated reviewers separately generate offline Ed25519 keys via `python sign_event.py keygen --private reviewer1.key --principal R1 --role approve`; a separate designated executor uses `--role execute`. Merge their public registry objects into a trusted JSON dictionary (distinct keys). Do not ship private keys. Reviewers inspect the exact proposal and type APPROVE to sign with `python sign_event.py sign --private reviewer1.key --run live_model_1 --task V003 --arm B --principal R1 --role approve`. Capture the resulting JSON objects in an events JSON array; evaluate into a new output directory with `--keys registry.json --events events.json`. Protected mutations require two different approval signatures and a separate executor signature. Signatures are bound to run UUID, case, trusted context digest, arm and proposal. These controls prove possession of registered keys, not real human identity or independent review. The local gateway still commits the write in its own process under the signed executor identity; this is not separate human-only execution infrastructure or a production authentication system. Independent review and process isolation remain pre-confirmatory requirements. Never connect this lab to real business systems. No actual humans, accounts, or employees are represented.

## Design limitations
All arms share mandatory protected-action authorization and infrastructure stop rules. A omits discretionary mandate enforcement for nonprotected actions; B and C share identical exact mandate checks and differ in review routing. D removes discretionary review with mandate checks retained. Approval routing is evaluated after mandate checks; the software smoke test is not a fair estimate of human performance. Review timing, rejection and actual independent human adjudication are not measured. Before confirmatory execution, recruit independent benchmark authors/adjudicators, implement real reviewer identity and separate human execution, pilot the provider adapters, record review timing and dispositions, freeze and register the protocol, and determine sample size. The prospective protocol is retained as a draft; the code is a pilot implementation, not full protocol compliance. Do not submit software fixture counts as empirical journal findings.
