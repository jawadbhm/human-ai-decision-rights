"""Prospective descriptive analysis, no empirical results bundled.
CSV columns: task_id,model,stratum,arm,unsafe,eligible,completion,review.
One row per task/model/arm, arms A B C D; binary outcomes 0/1. Eligibility must
match within task/model. Noncompletion on failed calls must remain in the input.
Analyze each model separately; this script does not adjust for reviewer clustering.
"""
import argparse,csv,math,random,collections,json
ARMS=set('ABCD')
METRICS=('unsafe','completion','review')
def upper_binomial(k,n,alpha=.05):
    if not n: return None
    if k==n:return 1.0
    def cdf(p):
        if p<=0:return 1.0
        if p>=1:return 0.0
        logs=[math.lgamma(n+1)-math.lgamma(i+1)-math.lgamma(n-i+1)+i*math.log(p)+(n-i)*math.log1p(-p) for i in range(k+1)]
        m=max(logs);return math.exp(m)*sum(math.exp(x-m) for x in logs)
    lo,hi=0.,1.
    for _ in range(60):
        mid=(lo+hi)/2
        if cdf(mid)>alpha:lo=mid
        else:hi=mid
    return hi

def analyze(rows,draws=10000,seed=20261128):
    grouped=collections.defaultdict(dict)
    for row in rows:
        key=(row['model'],row['task_id']); arm=row['arm']; assert arm in ARMS and arm not in grouped[key],key
        for k in ('unsafe','eligible','completion','review'):
            assert row[k] in ('0','1',0,1);row[k]=int(row[k])
        grouped[key][arm]=row
    models=collections.defaultdict(list)
    for (model,task),g in grouped.items():
        assert set(g)==ARMS,(model,task,'incomplete arm records')
        assert len({r['eligible'] for r in g.values()})==len({r['stratum'] for r in g.values()})==1
        models[model].append(g)
    assert models,'empty data'
    out={};rng=random.Random(seed)
    for model,groups in sorted(models.items()):
        results={}
        for left,right in [('C','B'),('C','A'),('D','A'),('C','D')]:
            bymetric={}
            for m in METRICS:
                elig=[g for g in groups if m!='completion' or g[left]['eligible']];n=len(elig)
                if not n:continue
                strata=collections.defaultdict(list)
                for g in elig:strata[g[left]['stratum']].append(g[left][m]-g[right][m])
                diff=[x for v in strata.values() for x in v]
                boot=sorted(sum(sum(rng.choices(v,k=len(v))) for v in strata.values())/n for _ in range(draws))
                adverse=sum(x==1 for x in diff) if m=='unsafe' else sum(x==-1 for x in diff)
                result={'n':n,'left_rate':sum(g[left][m] for g in elig)/n,'right_rate':sum(g[right][m] for g in elig)/n,'difference':sum(diff)/n,'descriptive_bootstrap_95':[boot[int(.025*(draws-1))],boot[int(.975*(draws-1))]],'positive_discordant':sum(x==1 for x in diff),'negative_discordant':sum(x==-1 for x in diff)}
                if m in ('unsafe','completion'):result['conservative_adverse_difference_upper_95']=upper_binomial(adverse,n)
                bymetric[m]=result
            results[left+'-'+right]=bymetric
        out[model]=results
    return out

def test():
    rows=[dict(task_id=str(i),model='software-test-only',stratum='test',arm=a,unsafe=int(a=='A' and i<2),eligible=1,completion=1,review=int(a=='B')) for i in range(10) for a in 'ABCD']
    r=analyze(rows,1000)['software-test-only'];assert abs(r['C-A']['unsafe']['difference']+.2)<1e-9;assert r['C-B']['review']['difference']==-1;assert abs(upper_binomial(0,100)-(1-.05**.01))<1e-10
    print('PASS: software-only synthetic self-test; no empirical data or live calls.')
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('input',nargs='?');p.add_argument('--self-test',action='store_true');a=p.parse_args()
    if a.self_test:test()
    elif a.input:
        with open(a.input,newline='') as f:print(json.dumps(analyze(list(csv.DictReader(f))),indent=2))
    else:p.error('provide CSV or --self-test')
