# Decision Rights in Human–AI Organizations
## Prospective theoretical extension — November 28, 2026

**Status:** Draft for author approval; not an empirical result or a registered analysis plan.

### Delegation and review as a cost-minimization problem
Consider a permitted task with probability p of correct execution by an agent. An execution error incurs loss Ce. Human review takes t hours at wage w, adds delay cost d, detects and prevents an erroneous action with probability s, and rejects a correct action with probability f. An incorrect rejection incurs opportunity cost Co. Assume risk neutrality, exogenous review performance conditional on task characteristics, and no residual loss for an error successfully prevented. A correction or rework cost could be included as an extension.

Autonomous expected loss: LA = (1 − p)Ce.
Reviewed expected loss: LH = (1 − p)(1 − s)Ce + pfCo + wt + d.
Review is preferred if (1 − p)sCe > pfCo + wt + d.
For sCe + fCo > 0, this is equivalent to p < p* = (sCe − wt − d)/(sCe + fCo). If p* is nonpositive, discretionary review is not optimal for any feasible positive accuracy. At equality the principal is indifferent. If the denominator is zero, compare losses directly. Mandatory controls constrain the feasible action set before optimizing. The expression is a reduced-form delegation model, not a full incentive-contracting model.

Comparative statics (holding other parameters fixed): increasing error loss weakly increases the review threshold; increasing wage, review duration, delay cost, or false-rejection cost weakly decreases it within the interior solution. Increasing reviewer detection sensitivity weakly increases the threshold. These predictions require task-level risk estimates and independent review observations, not the assumed error rates in the existing simulation.

### Testable extension
Estimate proposal correctness on a frozen development set, calibrate probabilities on a separate set, and evaluate thresholds on a locked holdout. Estimate review sensitivity, false rejection and review time using reviewers who do not see the labels. Randomize or prespecify error-cost and delay-cost schedules independently of outcomes. Evaluate realized loss and review frequency on the held-out tasks, comparing risk-tiered routing against blanket review and a budget-matched alternative. Keep protected tasks outside discretionary optimization. Report observed safety, task completion and review time separately from modeled monetary loss. Do not interpret analyst-assigned costs as actual organizational losses.

### Literature foundations (verified starting set, not a complete review)
- Aghion, P., & Tirole, J. (1997). Formal and Real Authority in Organizations. Journal of Political Economy. https://doi.org/10.1086/262063
- Garicano, L. (2000). Hierarchies and the Organization of Knowledge in Production. Journal of Political Economy. https://doi.org/10.1086/317671
- Dessein, W. (2002). Authority and Communication in Organizations. Review of Economic Studies. https://doi.org/10.1111/1467-937X.00227
- Hadfield-Menell, D., & Hadfield, G. K. (2019). Incomplete Contracting and AI Alignment. AIES. https://arxiv.org/abs/1804.04268
- Lebovitz, S., Lifshitz-Assaf, H., & Levina, N. (2022). To Engage or Not to Engage with AI for Critical Judgments: How Professionals Deal with Opacity When Using AI for Medical Diagnosis. Organization Science. https://doi.org/10.1287/orsc.2021.1549
- Fügener, A., Grahl, J., Gupta, A., & Ketter, W. (2022). Cognitive Challenges in Human–Artificial Intelligence Collaboration: Investigating the Path Toward Productive Delegation. Information Systems Research. https://doi.org/10.1287/isre.2021.1079
- Logg, J. M., Minson, J. A., & Moore, D. A. (2019). Algorithm Appreciation: People Prefer Algorithmic to Human Judgment. Organizational Behavior and Human Decision Processes. https://doi.org/10.1016/j.obhdp.2018.12.005
- Brynjolfsson, E., Li, D., & Raymond, L. (2025). Generative AI at Work. Quarterly Journal of Economics. https://doi.org/10.1093/qje/qjae044
- AgentDojo (2024), NeurIPS Datasets and Benchmarks. https://arxiv.org/abs/2406.13352
- ToolEmu (2024), ICLR. https://arxiv.org/abs/2309.15817

Expand the literature review by tracing these papers' relevant citations and recent citing work; do not pad the reference count with irrelevant citations.
